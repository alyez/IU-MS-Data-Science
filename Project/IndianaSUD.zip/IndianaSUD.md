
# Visualizing high dimensional TEDS data


```python
import matplotlib.pyplot as plt
import pandas as pd

import seaborn as sns

import numpy as np
import scipy.stats as ss

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
```


```python
df=pd.read_csv('__TEDSCountyLevel2008-2017_2.csv')
```


```python
%matplotlib inline
```


```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Alcohol</th>
      <th>Amphetamine</th>
      <th>Barbiturates</th>
      <th>Benzine</th>
      <th>Age</th>
      <th>State</th>
      <th>Cocaine</th>
      <th>County Name</th>
      <th>Gender</th>
      <th>Hal</th>
      <th>...</th>
      <th>OTC Primary</th>
      <th>Other Drugs Primary</th>
      <th>Pain Killers</th>
      <th>Pain Killers Primary</th>
      <th>PCP Primary</th>
      <th>Race.1</th>
      <th>Rx</th>
      <th>Rx Primary</th>
      <th>Stimulants Primary</th>
      <th>Trnq Primary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>18-24</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>55+</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>18-24</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>55+</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>55+</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25-34</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>35-44</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25-34</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0-18</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25-34</td>
      <td>Indiana</td>
      <td>0</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>White</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 50 columns</p>
</div>




```python
#Limit the number of features
features = ['Year','County Name','Gender','Race','Age','Alcohol','Heroin','Marijuana','Opioid','Cocaine','Other Drugs','Pain Killers', 'Methamphetamine', 'Synthetic Drugs']
df_subset = df[features]
df_subset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>County Name</th>
      <th>Gender</th>
      <th>Race</th>
      <th>Age</th>
      <th>Alcohol</th>
      <th>Heroin</th>
      <th>Marijuana</th>
      <th>Opioid</th>
      <th>Cocaine</th>
      <th>Other Drugs</th>
      <th>Pain Killers</th>
      <th>Methamphetamine</th>
      <th>Synthetic Drugs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2009</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>White</td>
      <td>18-24</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2009</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>White</td>
      <td>55+</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2009</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>White</td>
      <td>18-24</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2009</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>White</td>
      <td>55+</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2009</td>
      <td>Pulaski</td>
      <td>Male</td>
      <td>White</td>
      <td>55+</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
import altair as alt
alt.renderers.enable('notebook')
```




    RendererRegistry.enable('notebook')




```python
#Create a dataset for the 9 substances to use in correlations
features = ['Alcohol','Heroin','Marijuana','Opioid','Cocaine','Other Drugs','Pain Killers', 'Methamphetamine', 'Synthetic Drugs']
df_only_features = df_subset[features]
df_only_features.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Alcohol</th>
      <th>Heroin</th>
      <th>Marijuana</th>
      <th>Opioid</th>
      <th>Cocaine</th>
      <th>Other Drugs</th>
      <th>Pain Killers</th>
      <th>Methamphetamine</th>
      <th>Synthetic Drugs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
n_samples, n_features = df_only_features.shape
print(n_samples)
print(n_features)
```

    335866
    9
    


```python
#Check correlation between substances
import seaborn as sns

f, ax = plt.subplots(figsize=(9, 9))
corr = df_only_features.corr()
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True), center=0,
            square=True, ax=ax,annot=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1bd9f9260b8>




![png](output_9_1.png)


There is strong correlation between Pain Killers and Synthetic Drugs, supported by the Opioids. Heroin appears in 57% of the cases with Opioids. Alcohol is slightly negatively correlates with all four of them. 

#### Remarkably, there appears to be no appreciable correlation between opioid use and such commonly accepted and complementary socio-economic markers as alcohol, marijuana, or methamphetamine use. In fact, these three factors are likely to be biased towards older population (alcohol), younger population (marijuana) and underprivileged rural population (methamphetamine). 
#### Thus, it appears that opioid abuse have roots that are different from the common socio-economic maladies reflected in these three markers. 



```python
df_subset['County Name'].nunique()
```




    93




```python
df_subset['Year'].nunique()
```




    10




```python
# Total number of records
len(df_subset)
```




    335866




```python
#How many records per year
df_subset['Year'].value_counts()
```




    2017    37459
    2015    34739
    2011    34677
    2014    34470
    2012    33984
    2013    33616
    2016    33170
    2009    32049
    2010    31827
    2008    29875
    Name: Year, dtype: int64




```python
#How many records per county 
df_subset['County Name'].value_counts()
```




    Marion          41678
    Lake            25329
    Allen           16940
    Vanderburgh     14085
    Monroe          13842
    Saint Joseph    13359
    Delaware        10453
    Madison          9594
    Elkhart          8309
    Hamilton         8033
    Vigo             7895
    Howard           6235
    Bartholomew      6037
    Porter           5455
    LaPorte          5086
    Morgan           5057
    Lawrence         4557
    Tippecanoe       4514
    Wayne            4391
    Grant            4241
    Dearborn         3981
    Clark            3857
    Hendricks        3488
    Knox             3350
    Noble            3024
    Montgomery       3006
    Warrick          2969
    Kosciusko        2946
    Jefferson        2888
    Johnson          2834
                    ...  
    Perry            1407
    Rush             1281
    Shelby           1246
    Vermillion       1241
    Wells            1195
    Jay              1193
    Orange           1174
    Franklin         1115
    Huntington       1107
    Parke            1084
    Whitley          1031
    Carroll           967
    Brown             922
    Pulaski           906
    Jasper            902
    Sullivan          812
    Blackford         759
    Washington        681
    Fountain          662
    Martin            638
    Tipton            563
    Switzerland       562
    Crawford          511
    Harrison          461
    Pike              433
    Benton            373
    Newton            315
    Ohio              293
    Union             284
    Warren            229
    Name: County Name, Length: 93, dtype: int64




```python
# General method to variably group the data
def group_dataset(df, col1, col2):
    df_grouped=df.groupby([col1,col2])
    return df_grouped
```


```python
#Group by Year and County
df_grouped=group_dataset(df_subset, 'Year','County Name')

#Excluded pain killers and synthetic drugs as highly correclated with opioids
feature=['Alcohol','Heroin','Marijuana','Opioid','Cocaine','Other Drugs','Methamphetamine']
df_grouped=df_grouped[feature].mean()

df_grouped.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Alcohol</th>
      <th>Heroin</th>
      <th>Marijuana</th>
      <th>Opioid</th>
      <th>Cocaine</th>
      <th>Other Drugs</th>
      <th>Methamphetamine</th>
    </tr>
    <tr>
      <th>Year</th>
      <th>County Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">2008</th>
      <th>Adams</th>
      <td>0.905263</td>
      <td>0.021053</td>
      <td>0.684211</td>
      <td>0.105263</td>
      <td>0.231579</td>
      <td>0.0</td>
      <td>0.010526</td>
    </tr>
    <tr>
      <th>Allen</th>
      <td>0.863495</td>
      <td>0.012480</td>
      <td>0.641186</td>
      <td>0.048362</td>
      <td>0.325273</td>
      <td>0.0</td>
      <td>0.017161</td>
    </tr>
    <tr>
      <th>Bartholomew</th>
      <td>0.651106</td>
      <td>0.004914</td>
      <td>0.542998</td>
      <td>0.226044</td>
      <td>0.255528</td>
      <td>0.0</td>
      <td>0.299754</td>
    </tr>
    <tr>
      <th>Benton</th>
      <td>0.840000</td>
      <td>0.000000</td>
      <td>0.520000</td>
      <td>0.040000</td>
      <td>0.160000</td>
      <td>0.0</td>
      <td>0.040000</td>
    </tr>
    <tr>
      <th>Blackford</th>
      <td>0.833333</td>
      <td>0.000000</td>
      <td>0.620370</td>
      <td>0.157407</td>
      <td>0.175926</td>
      <td>0.0</td>
      <td>0.009259</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Group by County
df_grouped_c=group_dataset(df_subset,'County Name', 'Year')

#exclude pain killers and synthetic drugs as highly correclated with opioids
feature=['Alcohol','Heroin','Marijuana','Opioid','Cocaine','Other Drugs','Methamphetamine']
df_grouped_c=df_grouped_c[feature].mean()

df_grouped_c.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Alcohol</th>
      <th>Heroin</th>
      <th>Marijuana</th>
      <th>Opioid</th>
      <th>Cocaine</th>
      <th>Other Drugs</th>
      <th>Methamphetamine</th>
    </tr>
    <tr>
      <th>County Name</th>
      <th>Year</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Adams</th>
      <th>2008</th>
      <td>0.905263</td>
      <td>0.021053</td>
      <td>0.684211</td>
      <td>0.105263</td>
      <td>0.231579</td>
      <td>0.000000</td>
      <td>0.010526</td>
    </tr>
    <tr>
      <th>2009</th>
      <td>0.877863</td>
      <td>0.007634</td>
      <td>0.549618</td>
      <td>0.099237</td>
      <td>0.175573</td>
      <td>0.000000</td>
      <td>0.030534</td>
    </tr>
    <tr>
      <th>2010</th>
      <td>0.613497</td>
      <td>0.141104</td>
      <td>0.496933</td>
      <td>0.300613</td>
      <td>0.184049</td>
      <td>0.147239</td>
      <td>0.042945</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>0.655405</td>
      <td>0.141892</td>
      <td>0.540541</td>
      <td>0.331081</td>
      <td>0.155405</td>
      <td>0.108108</td>
      <td>0.060811</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>0.756098</td>
      <td>0.073171</td>
      <td>0.528455</td>
      <td>0.203252</td>
      <td>0.178862</td>
      <td>0.138211</td>
      <td>0.040650</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Group by Year to genralize the output
df_grouped_year1=df_subset.groupby('Year')
df_grouped_year1=df_grouped_year1[feature].mean()

df_grouped_year1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Alcohol</th>
      <th>Heroin</th>
      <th>Marijuana</th>
      <th>Opioid</th>
      <th>Cocaine</th>
      <th>Other Drugs</th>
      <th>Methamphetamine</th>
    </tr>
    <tr>
      <th>Year</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2008</th>
      <td>0.661891</td>
      <td>0.038226</td>
      <td>0.506644</td>
      <td>0.155213</td>
      <td>0.223397</td>
      <td>0.000000</td>
      <td>0.087464</td>
    </tr>
    <tr>
      <th>2009</th>
      <td>0.682798</td>
      <td>0.049237</td>
      <td>0.514837</td>
      <td>0.177821</td>
      <td>0.194359</td>
      <td>0.000000</td>
      <td>0.091235</td>
    </tr>
    <tr>
      <th>2010</th>
      <td>0.632168</td>
      <td>0.055833</td>
      <td>0.490998</td>
      <td>0.186006</td>
      <td>0.157602</td>
      <td>0.119553</td>
      <td>0.096962</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>0.606050</td>
      <td>0.068662</td>
      <td>0.483837</td>
      <td>0.220607</td>
      <td>0.146899</td>
      <td>0.138593</td>
      <td>0.103556</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>0.590837</td>
      <td>0.094191</td>
      <td>0.471398</td>
      <td>0.275012</td>
      <td>0.156809</td>
      <td>0.154926</td>
      <td>0.112612</td>
    </tr>
  </tbody>
</table>
</div>




```python
# General method to pivot by two predictors
def create_pivot_df(df, col_name, index_name, val_name):
    pivot_df = df.pivot_table(columns=col_name, index= index_name, values= val_name, aggfunc='mean')
    return pivot_df
```


```python
#create a pivot table for alcohol
create_pivot_df(df_grouped,col_name='Year',index_name='County Name', val_name='Alcohol').head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Year</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
    <tr>
      <th>County Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Adams</th>
      <td>0.905263</td>
      <td>0.877863</td>
      <td>0.613497</td>
      <td>0.655405</td>
      <td>0.756098</td>
      <td>0.812030</td>
      <td>0.805195</td>
      <td>0.697143</td>
      <td>0.559322</td>
      <td>0.514905</td>
    </tr>
    <tr>
      <th>Allen</th>
      <td>0.863495</td>
      <td>0.834094</td>
      <td>0.812057</td>
      <td>0.794048</td>
      <td>0.672963</td>
      <td>0.736813</td>
      <td>0.729648</td>
      <td>0.674190</td>
      <td>0.665637</td>
      <td>0.619924</td>
    </tr>
    <tr>
      <th>Bartholomew</th>
      <td>0.651106</td>
      <td>0.605505</td>
      <td>0.442708</td>
      <td>0.400815</td>
      <td>0.458841</td>
      <td>0.522551</td>
      <td>0.501475</td>
      <td>0.410745</td>
      <td>0.345955</td>
      <td>0.318925</td>
    </tr>
    <tr>
      <th>Benton</th>
      <td>0.840000</td>
      <td>0.850000</td>
      <td>0.684211</td>
      <td>0.794118</td>
      <td>0.852941</td>
      <td>0.659091</td>
      <td>0.708333</td>
      <td>0.750000</td>
      <td>0.780000</td>
      <td>0.627451</td>
    </tr>
    <tr>
      <th>Blackford</th>
      <td>0.833333</td>
      <td>0.787234</td>
      <td>0.216216</td>
      <td>0.523810</td>
      <td>0.519231</td>
      <td>0.386364</td>
      <td>0.440678</td>
      <td>0.454545</td>
      <td>0.378049</td>
      <td>0.333333</td>
    </tr>
  </tbody>
</table>
</div>




```python
def draw_heatmap(df, nrows, ncols):
    f, ax = plt.subplots(figsize=(nrows, ncols))    
    sns.heatmap(df,  cmap=sns.cubehelix_palette(8, start=.5, rot=-.75),ax=ax,xticklabels=2, square=True, vmin=0, vmax=.9)
```


```python
def draw_heatmap_corr(df, nrows, ncols):
    f, ax = plt.subplots(figsize=(nrows, ncols)) 
    df=df.corr()
    sns.heatmap(df,  cmap=sns.diverging_palette(220, 10, as_cmap=True), center=0,ax=ax, square=True,annot=True,cbar_kws={"shrink": .5})  
```


```python
#Transpose the matrix
df_grouped_year_T= df_grouped_year1.T
df_grouped_year_T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Year</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alcohol</th>
      <td>0.661891</td>
      <td>0.682798</td>
      <td>0.632168</td>
      <td>0.606050</td>
      <td>0.590837</td>
      <td>0.585792</td>
      <td>0.559066</td>
      <td>0.528743</td>
      <td>0.501326</td>
      <td>0.469954</td>
    </tr>
    <tr>
      <th>Heroin</th>
      <td>0.038226</td>
      <td>0.049237</td>
      <td>0.055833</td>
      <td>0.068662</td>
      <td>0.094191</td>
      <td>0.105396</td>
      <td>0.121787</td>
      <td>0.156625</td>
      <td>0.185680</td>
      <td>0.207187</td>
    </tr>
    <tr>
      <th>Marijuana</th>
      <td>0.506644</td>
      <td>0.514837</td>
      <td>0.490998</td>
      <td>0.483837</td>
      <td>0.471398</td>
      <td>0.476172</td>
      <td>0.478648</td>
      <td>0.483462</td>
      <td>0.483389</td>
      <td>0.484690</td>
    </tr>
    <tr>
      <th>Opioid</th>
      <td>0.155213</td>
      <td>0.177821</td>
      <td>0.186006</td>
      <td>0.220607</td>
      <td>0.275012</td>
      <td>0.303248</td>
      <td>0.314244</td>
      <td>0.339273</td>
      <td>0.359029</td>
      <td>0.371046</td>
    </tr>
    <tr>
      <th>Cocaine</th>
      <td>0.223397</td>
      <td>0.194359</td>
      <td>0.157602</td>
      <td>0.146899</td>
      <td>0.156809</td>
      <td>0.131277</td>
      <td>0.112446</td>
      <td>0.106825</td>
      <td>0.105788</td>
      <td>0.107851</td>
    </tr>
    <tr>
      <th>Other Drugs</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.119553</td>
      <td>0.138593</td>
      <td>0.154926</td>
      <td>0.165516</td>
      <td>0.177894</td>
      <td>0.202654</td>
      <td>0.223184</td>
      <td>0.227262</td>
    </tr>
    <tr>
      <th>Methamphetamine</th>
      <td>0.087464</td>
      <td>0.091235</td>
      <td>0.096962</td>
      <td>0.103556</td>
      <td>0.112612</td>
      <td>0.121995</td>
      <td>0.141514</td>
      <td>0.159936</td>
      <td>0.196955</td>
      <td>0.248538</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Show a trend relative to other substances
draw_heatmap(df_grouped_year_T, 10, 7)
```


![png](output_25_0.png)



```python
# Draw a heatmap by County for Alcohol
draw_heatmap(
create_pivot_df(df_grouped,'Year','County Name', 'Alcohol'), 186, 20)
```


![png](output_26_0.png)



```python
#Opioid
draw_heatmap(create_pivot_df(df_grouped,'Year','County Name', 'Opioid'), 186, 20)
```


![png](output_27_0.png)



```python
#Marijuana
draw_heatmap(create_pivot_df(df_grouped,'Year','County Name', 'Marijuana'), 186, 20)
```


![png](output_28_0.png)



```python
# Methamphetamine
draw_heatmap(create_pivot_df(df_grouped,'Year','County Name', 'Methamphetamine'), 186, 20)
```


![png](output_29_0.png)


#### From the four heatmaps above, one could infer the following observations: 
- while Alcohol remains the most commonly abused substance, its dominance is vaning as the prevalence of other substances, especially opiods and methamphethamine increases. At the same time, marijuana abuse remains fairly stable.  

### Suplimentary Analysis: Identify any years that differ from the majority


```python
draw_heatmap_corr(create_pivot_df(df_grouped,'Year','County Name', 'Alcohol'), 10,10)
```


```python
#Marijuana
draw_heatmap_corr(create_pivot_df(df_grouped,'Year','County Name', 'Marijuana'), 10,10)
```


![png](output_33_0.png)



```python
#Opioids
draw_heatmap_corr(create_pivot_df(df_grouped,'Year','County Name', 'Opioid'), 10,10)
```


![png](output_34_0.png)



```python
#Methamphetamine
draw_heatmap_corr(create_pivot_df(df_grouped,'Year','County Name', 'Methamphetamine'), 10,10)
```


![png](output_35_0.png)


Beginning 2012 the usage patterns became very similar for the malority of the subjects that requested treatment in Indiana.

### Suplimentary Analysis: Identify counties that differ from the majority


```python
draw_heatmap_corr(create_pivot_df(df_grouped,'County Name','Year', 'Alcohol'), 93,93)
```


![png](output_38_0.png)



```python
draw_heatmap_corr(create_pivot_df(df_grouped,'County Name','Year', 'Opioid'), 93,93)
```


![png](output_39_0.png)



```python
draw_heatmap_corr(create_pivot_df(df_grouped,'County Name','Year', 'Marijuana'), 93,93)
```


![png](output_40_0.png)



```python
draw_heatmap_corr(create_pivot_df(df_grouped,'County Name','Year', 'Other Drugs'), 93,93)
```


![png](output_41_0.png)



```python
draw_heatmap_corr(create_pivot_df(df_grouped,'County Name','Year', 'Heroin'), 93,93)
```


![png](output_42_0.png)



```python
draw_heatmap_corr(create_pivot_df(df_grouped,'County Name','Year', 'Methamphetamine'), 93,93)
```


![png](output_43_0.png)


## Suplimentary analisys: PCA 

The [principal component analysis (PCA)](http://setosa.io/ev/principal-component-analysis/) is the most basic dimensionality reduction method. To run the PCA we want to isolate only the numerical columns. 


```python
from sklearn.decomposition import PCA
pca = PCA() 
```

Now I ran `fit()` method to identify principal components. 


```python
pca_df_fitted = pca.fit(df_only_features)
print(pca.components_)

```

    [[-3.85284978e-01  1.74017452e-01 -1.44132829e-01  5.72548369e-01
      -2.69179141e-02 -9.45944737e-04  4.88667622e-01  2.68324235e-02
       4.82126552e-01]
     [-4.18457857e-01 -5.05321504e-03  9.00800758e-01 -1.84296925e-02
      -5.53315489e-03  1.53651275e-03 -2.34787354e-02  1.09207683e-01
      -2.39850374e-02]
     [ 7.11756112e-01 -2.43212736e-01  3.74058306e-01  9.21887106e-02
      -1.39977393e-01 -4.67858705e-02  3.29558300e-01 -2.17148697e-01
       3.29070826e-01]
     [ 6.54654403e-02  2.33536949e-01  7.81258265e-02  1.44714164e-01
       6.66987977e-01 -5.86190546e-01 -6.12216977e-02 -3.43352728e-01
      -6.32252001e-02]
     [ 7.12073209e-02  4.07014556e-01  9.88869180e-02  2.09251566e-01
       5.82755415e-02  6.54588384e-01 -1.35008442e-01 -5.53985972e-01
      -1.36726374e-01]
     [-2.01654654e-01 -5.55680657e-01 -7.19214685e-02 -2.79439087e-01
       5.74989672e-01  3.75006655e-01  1.92924758e-01 -1.44138780e-01
       1.95080605e-01]
     [ 3.46163005e-01  2.35182719e-01  8.23741063e-02  1.93313001e-01
       4.47977083e-01  2.91666275e-01 -1.35950867e-02  7.03277331e-01
      -1.29745391e-02]
     [ 3.90868442e-04  5.68343537e-01  4.84514642e-03 -6.90996902e-01
       9.17264956e-03 -1.72477268e-03  2.33910579e-01  5.52881945e-03
       3.80333325e-01]
     [ 1.39976189e-03  5.68623039e-02  4.14804014e-04 -7.54235243e-02
       1.18822447e-03  5.79425375e-04  7.33450549e-01  1.74171781e-03
      -6.73142890e-01]]
    

'-Other Drugs', Marijuana,Opioid+Alcohol, Marijuana+Cocaine, Marijuana+Alcohol, -Marijuana-Heroin, Marijuana+Methamphetamine


```python
print(pca.explained_variance_)

```

    [0.52332706 0.25520259 0.20435398 0.13614426 0.12185475 0.1103172
     0.10171866 0.00989851 0.00189358]
    


```python
pca_df_fitted.explained_variance_ratio_
```




    array([0.35729042, 0.17423414, 0.13951833, 0.0929496 , 0.08319374,
           0.07531672, 0.06944625, 0.006758  , 0.0012928 ])




```python
pca.components_.shape
```




    (9, 9)




```python
plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel('number of components')
plt.ylabel('cumulative explained variance');
```


![png](output_52_0.png)


The first six components capture more than 95% of the variance in original dataset. This means that the PCA is not very effective on this dataset and six components will provide approximation for the rest of the dimensions. 
